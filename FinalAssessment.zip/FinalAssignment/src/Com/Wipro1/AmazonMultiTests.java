package Com.Wipro1;

import org.testng.annotations.Test;
import java.io.File;
import java.io.FileInputStream;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class AmazonMultiTests {

	WebDriver driver;
	XSSFWorkbook workbook;
	XSSFSheet sheet;
	XSSFCell cell;
	String AmazonEmail;
	String AmazonPassword;
	String SearchHarryPotter;
	String EnterDummy;
	String EntercelloChair;

	@Test
	public void test1() {
		try {
			// import xlsx
			File src = new File("E:/Selenium/logindata.xlsx");

			// Load File
			FileInputStream fis = new FileInputStream(src);

			// Load Work Book
			workbook = new XSSFWorkbook(fis);

			// Load sheet
			sheet = workbook.getSheet("Sheet1");

		} catch (Exception e) {
			e.printStackTrace();
		}

		// Get Email From xlsx
		cell = sheet.getRow(0).getCell(0);
		AmazonEmail = cell.getStringCellValue();
		System.out.println("Email :" + cell.getStringCellValue());

		// Get password from xlsx
		cell = sheet.getRow(0).getCell(1);
		AmazonPassword = cell.getStringCellValue();
		System.out.println("Password :" + cell.getStringCellValue());

		// Get Harry Potter From xlsx
		cell = sheet.getRow(0).getCell(2);
		SearchHarryPotter = cell.getStringCellValue();
		System.out.println("Value Entered: " + cell.getStringCellValue());

		// Get Harry Potter From xlsx
		cell = sheet.getRow(0).getCell(3);
		EnterDummy = cell.getStringCellValue();
		System.out.println("Value Entered: " + cell.getStringCellValue());

		// Get cello chair From xlsx
		cell = sheet.getRow(0).getCell(4);
		EntercelloChair = cell.getStringCellValue();
		System.out.println("Value Entered: " + cell.getStringCellValue());

	}

	@Test
	public void test2() {

		// Click on login Button
		driver.findElement(By.xpath("//span[@id='nav-link-accountList-nav-line-1']")).click();

		// Enter Email
		driver.findElement(By.id("ap_email")).sendKeys(AmazonEmail);

		// Click on Continue
		driver.findElement(By.id("continue")).submit();

		// Enter Password
		driver.findElement(By.id("ap_password")).sendKeys(AmazonPassword);

		// Click On SignIn
		driver.findElement(By.id("signInSubmit")).click();

	}

	@Test
	public void test3() throws InterruptedException {

		// Parent Window ID
		String Parent = driver.getWindowHandle();

		// Click on Hamburger menu
		driver.findElement(By.xpath("//i[contains(@class,'hm-icon nav-sprite')]")).click();

		// Wait for 2sec
		Thread.sleep(2000);

		// Click On See ALL
		driver.findElement(By.xpath("//i[@class='nav-sprite hmenu-arrow-more']")).click();

		// Scroll
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement book = driver.findElement(By.xpath("(//a[@class='hmenu-item'][contains(.,'Books')])[2]"));
		js.executeScript("arguments[0].scrollIntoView();", book);

		// Click On Books
		driver.findElement(By.xpath("(//a[@class='hmenu-item'][contains(.,'Books')])[2]")).click();

		// Wait for 1sec
		Thread.sleep(1000);

		// Click on Children Books
		driver.findElement(By.linkText("Children's Books")).click();

		// Wait for 1sec
		Thread.sleep(1000);

		// Search for harry potter
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys(SearchHarryPotter);

		// Click on Search button
		driver.findElement(By.id("nav-search-submit-button")).click();

		// Wait for 1sec
		Thread.sleep(1000);

		// Select the first Book
		driver.findElement(By.xpath("(//span[contains(@class,'a-size-medium a-color-base a-text-normal')])[1]"))
				.click();

		Set<String> allWindows = driver.getWindowHandles();

		for (String child : allWindows) {
			if (!Parent.equalsIgnoreCase(child)) {
				driver.switchTo().window(child);

				// Click on wish list drop-down button
				driver.findElement(By.xpath("//input[@id='add-to-wishlist-button']")).click();

				// Wait for 1sec
				Thread.sleep(2000);

				// Click on new create wish-list
				driver.findElement(By.xpath("//span[@data-action='show-create-list']")).click();

				// Wait for 1sec
				Thread.sleep(1000);

				// Input wish-list name
				driver.findElement(By.xpath("//input[contains(@id,'list-name')]")).clear();
				driver.findElement(By.xpath("//input[contains(@id,'list-name')]")).sendKeys(EnterDummy);

				// Wait for 1sec
				Thread.sleep(1000);

				// Click on Create
				driver.findElement(By.xpath("(//input[contains(@class,'a-button-input a-declarative')])[4]")).click();

				// Wait for 1sec
				Thread.sleep(1000);

				// Click on Continue Shopping
				driver.findElement(By.xpath("//button[contains(.,'Continue shopping')]")).click();
				driver.close();
				driver.switchTo().window(Parent);

			}
		}

	}

	@Test
	public void test4() throws InterruptedException {
		
		// Search for cello chair
		driver.findElement(By.id("twotabsearchtextbox")).clear();
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys(EntercelloChair);
		
		// Parent Window ID
		String Parent = driver.getWindowHandle();

		// Click on Search button
		driver.findElement(By.id("nav-search-submit-button")).click();
		
		// Wait for 1sec
		Thread.sleep(1000);

		// Select the first Product
		driver.findElement(By.xpath("(//span[contains(@class,'a-size-medium a-color-base a-text-normal')])[1]"))
				.click();

		Set<String> allWin = driver.getWindowHandles();
		for (String child : allWin) {
			if (!Parent.equalsIgnoreCase(child)) {
				driver.switchTo().window(child);
				
				// Wait for 1sec
				Thread.sleep(1000);

				// Select Quantity
				Select qualityCount = new Select(driver.findElement(By.id("quantity")));
				qualityCount.selectByIndex(1);

				// Wait for 1sec
				Thread.sleep(1000);

				// Add to cart
				driver.findElement(By.id("add-to-cart-button")).click();

				// Wait for 1sec
				Thread.sleep(1000);

				// Navigate to Cart
				driver.findElement(By.xpath("//span[contains(@id,'nav-cart-count')]")).click();

				// Wait for 1sec
				Thread.sleep(1000);

				// Delete Items from cart
				driver.findElement(By.xpath("//input[contains(@aria-label,'Delete Cello Chair (Plastic, Brown)')]"))
						.click();

				// Close Window
				driver.close();

				// Switch to parent Tab
				driver.switchTo().window(Parent);

			}
		}
	}

	@Test
	public void test5() {
		// Move Over and SignOut
		Actions actions = new Actions(driver);
		WebElement menuOption = driver.findElement(By.xpath("//span[@id='nav-link-accountList-nav-line-1']"));
		actions.moveToElement(menuOption).perform();
		driver.findElement(By.xpath("//span[contains(.,'Sign Out')]")).click();
	}


	@BeforeTest
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "C:\\SelDriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
		driver.get("https://www.amazon.in/");

	}

	@AfterTest
	public void setdown() {
		driver.close();
	}
}
